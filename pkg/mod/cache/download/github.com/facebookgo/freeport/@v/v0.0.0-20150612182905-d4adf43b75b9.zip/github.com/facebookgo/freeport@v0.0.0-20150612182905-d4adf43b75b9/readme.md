freeport [![Build Status](https://secure.travis-ci.org/facebookgo/freeport.png)](http://travis-ci.org/facebookgo/freeport)
========

Find a free port. Documentation:
http://godoc.org/github.com/facebookgo/freeport
