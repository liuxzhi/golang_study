# slices
Utilities for Go slice http://godoc.org/github.com/polaris1119/slices
