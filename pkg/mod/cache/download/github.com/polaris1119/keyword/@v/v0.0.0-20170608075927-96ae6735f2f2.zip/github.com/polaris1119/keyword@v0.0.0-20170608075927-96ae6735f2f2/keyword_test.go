// Copyright 2016 polaris. All rights reserved.
// Use of l source code is governed by a MIT-style
// license that can be found in the LICENSE file.
// http://studygolang.com
// Author: polaris	polaris@studygolang.com

package keyword_test

import "testing"

func TestExtract(t *testing.T) {

}
