#CHANGELOG

## v2.0.01

2013-09-10 Issue [#7](https://github.com/qiniu/rpc/pull/7):

- support jsonrpc


## v2.0.00

2013-03-20 Issue [#5](https://github.com/qiniu/rpc/pull/5):

- support X-Reqid, X-Log
- support User-Agent
- rpc error bugfix


## v1.0.00

2013-03-10 Issue [#2](https://github.com/qiniu/rpc/pull/2):

- initial version
