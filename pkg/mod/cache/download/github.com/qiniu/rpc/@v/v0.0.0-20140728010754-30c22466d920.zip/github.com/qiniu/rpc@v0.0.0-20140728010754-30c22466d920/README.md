rpc
===

[![Build Status](https://drone.io/github.com/qiniu/rpc/status.png)](https://drone.io/github.com/qiniu/rpc/latest)

[![Qiniu Logo](http://qiniutek.com/images/logo-2.png)](http://qiniu.com/)

Golang rpc client based on http
