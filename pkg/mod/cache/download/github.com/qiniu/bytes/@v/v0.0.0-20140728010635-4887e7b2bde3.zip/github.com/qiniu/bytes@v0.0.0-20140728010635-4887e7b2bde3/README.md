bytes
=====

[![Build Status](https://drone.io/github.com/qiniu/bytes/status.png)](https://drone.io/github.com/qiniu/bytes/latest)

![logo](http://qiniutek.com/images/logo-2.png)

Extension module of golang bytes processing
