package api

import (
	_ "github.com/qiniu/api.v6/auth/digest"
	_ "github.com/qiniu/api.v6/conf"
	_ "github.com/qiniu/api.v6/fop"
	_ "github.com/qiniu/api.v6/io"
	_ "github.com/qiniu/api.v6/resumable/io"
	_ "github.com/qiniu/api.v6/rs"
	_ "github.com/qiniu/api.v6/url"
)
