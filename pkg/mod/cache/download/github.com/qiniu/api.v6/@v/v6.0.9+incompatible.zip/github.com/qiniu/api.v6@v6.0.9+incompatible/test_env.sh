export QINIU_ACCESS_KEY="<Please apply your access key>"
export QINIU_SECRET_KEY="<Dont send your secret key to anyone>"
export QINIU_TEST_BUCKET="<Bucket that run your test cases>"
export QINIU_TEST_DOMAIN="<Domain that binding to your test bucket>"
